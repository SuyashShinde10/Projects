﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient; 

public partial class frmDisplay : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    DataSet ds;
    SqlDataAdapter sda;
    int i, c, n;

    protected void Page_Load(object sender, EventArgs e)
    {
        Class1 x = new Class1();

        cn = new SqlConnection(x.s );
        cn.Open();
        ds = new DataSet();
        sda = new SqlDataAdapter();
        showData();

    }

    private void showData()
    {
        cm = new SqlCommand("select * from SALES", cn);
        sda.SelectCommand = cm;
        sda.Fill(ds, "SALES");
        ds.AcceptChanges();
        sda.Update(ds.Tables[0]);

        n = ds.Tables[0].Rows.Count;

        GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}