﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class frmPurchaseDetails : System.Web.UI.Page
{
    SqlDataReader dr1;
    SqlConnection cn;
    SqlCommand cm;
    DataSet ds,ds1,ds2;
    SqlDataAdapter sda;
    int i, c, n;
    float price;
    protected void Page_Load(object sender, EventArgs e)
    {
        txtPID.Text = Session["purId"].ToString();
        txtBillNO.Text = Session["purID"].ToString();
        txtDate.Text = Session["Date"].ToString();
        ddlCname.Text = Session["CompName"].ToString();
        //txtAmm.Text = Session["Amount"].ToString();

        if (ViewState["price"] != null)
        {
            price = float.Parse(ViewState["price"].ToString());

        }
        else
        {
            price = 0;
        }

        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
        else
        {
            c = 0;

        }
        Class1 x = new Class1();

        cn = new SqlConnection(x.s);
         
        cn.Open();
        ds = new DataSet();
        ds1 = new DataSet();
        ds2 = new DataSet();
        sda = new SqlDataAdapter();
        showData();
        showData2();
        findSrNo();
        //showData1();
    }
    private void showData1()
    {
        ds1.Clear();
        cm = new SqlCommand("select * from ITEM", cn);
        sda.SelectCommand = cm;
        sda.Fill(ds1, "ITEM");
        ds1.AcceptChanges();
        sda.Update(ds1.Tables[0]);

        //n = ds.Tables[0].Rows.Count;

        ddlItem.DataSource = ds1.Tables[0];
        ddlItem.DataTextField = "I_Name";
        ddlCname.DataValueField = "I_Name";
        ddlItem.DataBind();

    }
    private void showData2()
    {
        ds2.Clear();
        cm = new SqlCommand("select * from DEALER", cn);
        sda.SelectCommand = cm;
        sda.Fill(ds2, "DEALER");
        ds2.AcceptChanges();
        sda.Update(ds2.Tables[0]);

        ddlCname.DataSource = ds2.Tables[0];
        ddlCname.DataTextField = "D_Name";
        ddlCname.DataValueField = "D_Name";
        ddlCname.DataBind();

    }
    private void showData()
    {
        ds.Clear();
        cm = new SqlCommand("select * from PURCHSEDETAILS", cn);
        sda.SelectCommand = cm;
        sda.Fill(ds, "PURCHSEDETAILS");
        ds.AcceptChanges();
        sda.Update(ds.Tables[0]);

        n = ds.Tables[0].Rows.Count;

        GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();

    }
    public void clear()
    {
        //txtPID.Text = "";
        //txtBillNO.Text = "";
        //ddlCname.Text = "";
        //txtSRNO.Text = "";
        //ddlItem.Text = "";
        //ddlSize.Text = "";
        txtquantity.Text = "";
        txtAmm.Text = "";
        //txttotal.Text = "";
        //txtBillNO.Text = "";
         
    }
    private void eachRecord()
    {
        // showData();
        try
        {
            txtDate.Text = ds.Tables[0].Rows[c].ItemArray[0].ToString();
            txtPID.Text = ds.Tables[0].Rows[c].ItemArray[1].ToString();
            //DateTime d1 = DateTime.Parse(ds.Tables[0].Rows[c].ItemArray[2].ToString());
            txtBillNO.Text = ds.Tables[0].Rows[c].ItemArray[2].ToString();
            ddlCname.Text = ds.Tables[0].Rows[c].ItemArray[3].ToString();
            txtSRNO.Text = ds.Tables[0].Rows[c].ItemArray[4].ToString();
            ddlItem.Text = ds.Tables[0].Rows[c].ItemArray[5].ToString();
            ddlSize.Text = ds.Tables[0].Rows[c].ItemArray[6].ToString();
            txtquantity.Text = ds.Tables[0].Rows[c].ItemArray[7].ToString();
            txtAmm.Text = ds.Tables[0].Rows[c].ItemArray[8].ToString();
            //txttotal.Text = ds.Tables[0].Rows[c].ItemArray[9].ToString();
            //txtActAmm.Text = ds.Tables[0].Rows[c].ItemArray[10].ToString();
        }
        catch (Exception e1) { }
    }
     

    protected void btnnxt_Click(object sender, EventArgs e)
    {
        //next record
        if (c < n - 1)
        {
            c++;

            eachRecord();
            ViewState["c"] = c.ToString();

        }
        else
        {
            Response.Write("<script>alert('Last Record')</script>");
        }

    }


    protected void btnfirst_Click(object sender, EventArgs e)
    {
        //first record
        c = 0;

        eachRecord();
        ViewState["c"] = c.ToString();
    }

    protected void btnprev_Click(object sender, EventArgs e)
    {
        // previous
        if (c > 0)
        {
            c--;

            eachRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script> alert('First Record');</script>");
        }
    }

    protected void btnist_Click(object sender, EventArgs e)
    {
        ///last record

        try
        {
            c = n - 1;

            eachRecord();
            ViewState["c"] = c.ToString();

        }
        catch
        {
            c = n;
        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("Select * from PURCHSEDETAILS where p_Id=" + int.Parse(txtPID.Text), cn);
            SqlDataReader dr = cm.ExecuteReader();
            if (dr.Read())
            {
                txtDate.Text = dr[0].ToString();
                //DateTime d1 = DateTime.Parse(dr[2].ToString());
                txtBillNO.Text = dr[2].ToString();
                ddlCname.Text = dr[3].ToString();
                txtSRNO.Text = dr[4].ToString();
                ddlItem.Text = dr[5].ToString();
                ddlSize.Text = dr[6].ToString();
                txtquantity.Text = dr[7].ToString();
                txtAmm.Text = dr[8].ToString();
                //txttotal.Text = dr[9].ToString();
                //txtActAmm.Text = dr[10].ToString();
            }
            else
            {

            }
            dr.Close();
        }
        catch (Exception e11)
        {
            Response.Write(e11.ToString());
        }
    }
    int srNo;
    private void findSrNo()
    {
        try
        {
            cm = new SqlCommand("select max(p_SRNO) from PURCHSEDETAILS where p_Id=" + int.Parse(txtPID.Text), cn);
            dr1 = cm.ExecuteReader();
            if (dr1.Read())
            {
                srNo = int.Parse(dr1[0].ToString()) + 1;

            }

            dr1.Close();
        }
        catch (Exception e1)
        {
            srNo = 1;
            dr1.Close();
        }
        txtSRNO.Text = srNo.ToString();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        showData();
        if (txtDate.Text != "" && txtPID.Text != "" && txtBillNO.Text != "" && ddlCname.Text != "" && txtSRNO.Text != "" && ddlItem.Text != "" && ddlSize.Text != "" && txtquantity.Text != "" && txtAmm.Text != "")
        {
            cm = new SqlCommand("insert into  PURCHSEDETAILS  values (@p_Date,@p_Id,@p_No,@p_CName,@p_SRNO,@p_Item,@p_size,@p_Quantity,@p_Amount)", cn);

            //@d_id,@d_name,@d_dob,@d_age,@d_address,@d_contact,@d_bloodgroup,@d_desease_history
            cm.Parameters.AddWithValue("@p_Date",DateTime.Parse(txtDate.Text));
            cm.Parameters.AddWithValue("@p_Id", txtPID.Text);
            cm.Parameters.AddWithValue("@p_No", txtBillNO.Text);
            cm.Parameters.AddWithValue("@p_CName", ddlCname.Text);
            cm.Parameters.AddWithValue("@p_SRNO", txtSRNO.Text);
            cm.Parameters.AddWithValue("@p_Item", ddlItem.Text);
            cm.Parameters.AddWithValue("@p_size", ddlSize.Text);
            cm.Parameters.AddWithValue("@p_Quantity", txtquantity.Text);
            cm.Parameters.AddWithValue("@p_Amount", txtAmm.Text);
             

            sda.InsertCommand = cm;
            DataRow drw = ds.Tables[0].NewRow();
            //  drw[0] = int.Parse(txtIID.Text);
            drw[0] = DateTime.Parse(txtDate.Text);
            drw[1] = int.Parse(txtPID.Text);
            drw[2] = int.Parse(txtBillNO.Text);
            drw[3] = ddlCname.Text;
            drw[4] = int.Parse(txtSRNO.Text);
            drw[5] = ddlItem.Text;
            drw[6] = int.Parse(ddlSize.Text);
            drw[7] = int.Parse(txtquantity.Text);
            drw[8] = float.Parse(txtAmm.Text);
            //drw[9] = float.Parse(txttotal.Text);
            //drw[10] = float.Parse(txtActAmm.Text);
            ds.Tables[0].Rows.Add(drw);

            sda.Update(ds.Tables[0]);
            ds.AcceptChanges();
            showData();
            //clear();
        }
        else
        {
            Response.Write("<script>alert('Please fill your information ');</script>");
        }
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
    }

    protected void btnData_Click(object sender, EventArgs e)
    {
        showData1();
    }
    protected void btnCal_Click(object sender, EventArgs e)
    {
        float a = price * int.Parse(txtquantity.Text);
        txtAmm.Text = a.ToString();
    }
    protected void ddlItem_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {


            cm = new SqlCommand("select * from ITEM where I_Name='" + ddlItem.Text + "'", cn);
            dr1 = cm.ExecuteReader();
            if (dr1.Read())
            {

                price = float.Parse(dr1[8].ToString());
            }
            dr1.Close();
            ViewState["price"] = price.ToString();
        }
        catch (Exception gg)
        {
            dr1.Close();
        }
    }
     
    protected void btnFinish_Click1(object sender, EventArgs e)
    {
        Session["purId"] = txtPID.Text;
        Session["purID"] = txtBillNO.Text; 
        Session["Date"] = txtDate.Text;
        Session["CompName"] = ddlCname.Text;
        //Session["Amount"] = txtAmm.Text;

         
        int amt = 0;
        try
        {
            cm = new SqlCommand("select sum(P_Amount) from PURCHASE where P_Id=" + int.Parse(txtPID.Text), cn);
            dr1 = cm.ExecuteReader();
            if (dr1.Read())
            {
                amt = int.Parse(dr1[0].ToString());

            }

            dr1.Close();
        }
        catch (Exception e1)
        {

            dr1.Close();
        }
        txtSRNO.Text = srNo.ToString();
        Session["Amount"] = amt.ToString();

        Response.Redirect("frmPurchase.aspx");
    }
}