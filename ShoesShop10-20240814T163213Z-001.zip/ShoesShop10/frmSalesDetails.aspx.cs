﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class frmSalesDetails : System.Web.UI.Page
{
    SqlDataReader dr1;
    SqlConnection cn;
    SqlCommand cm;
    DataSet ds,ds1,ds2;
    SqlDataAdapter sda;
    int i, c, n;
    float price,a;
    protected void Page_Load(object sender, EventArgs e)
    {
        txtSalesID.Text = Session["SID"].ToString();
        txtBillingNO.Text = Session["SID"].ToString();
        txtDate.Text = Session["SDate"].ToString();
        ddlCname.Text = Session["Cname"].ToString();
        //txtAmmount.Text = Session["Amount"].ToString();

         

        if (ViewState["price"] != null)
        {
            price = float.Parse(ViewState["price"].ToString());

        }
        else
        {
            price = 0;
        }

        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
        else
        {
            c = 0;

        }
        Class1 x = new Class1();

        cn = new SqlConnection(x.s);
        cn.Open();
        ds = new DataSet();
        ds1 = new DataSet();
        ds2 = new DataSet();
        sda = new SqlDataAdapter();
        showData();
        showData2();
        findSrNo();
    }
    private void showData2()
    {
        ds2.Clear();
        cm = new SqlCommand("select * from CUSTOMER", cn);
        sda.SelectCommand = cm;
        sda.Fill(ds2, "CUSTOMER");
        ds2.AcceptChanges();
        sda.Update(ds2.Tables[0]);

   
        ddlCname.DataSource = ds2.Tables[0];
        ddlCname.DataTextField = "Cus_Name";
        ddlCname.DataValueField = "Cus_Name";
        ddlCname.DataBind();

    }
    private void showData()
    {
        try
        {
            ds.Clear();
            cm = new SqlCommand("select * from SALESDETAIL where s_Id=" + int.Parse(txtSalesID.Text), cn);
            sda.SelectCommand = cm;
            sda.Fill(ds, "SALESDETAIL");
            ds.AcceptChanges();
            sda.Update(ds.Tables[0]);

            n = ds.Tables[0].Rows.Count;

            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
        }
        catch (Exception gg) { }

    }
    private void showData1()
    {
        ds1.Clear();
        cm = new SqlCommand("select * from ITEM", cn);
        sda.SelectCommand = cm;
        sda.Fill(ds1, "ITEM");
        ds1.AcceptChanges();
        sda.Update(ds1.Tables[0]);

        //n = ds.Tables[0].Rows.Count;

        ddlIem.DataSource = ds1.Tables[0];
        ddlIem.DataTextField = "I_Name";
        ddlIem.DataValueField = "I_Name";
        ddlIem.DataBind();

    }

    public void clear()
    {
        //txtSalesID.Text = "";
        //txtBillingNO.Text = "";
        //ddlCname.Text = "";
        //txtSRNO.Text = "";
       // ddlIem.Text = "";
       // ddlSize.Text = "";
        txtQuantity.Text = "";
        txtAmmount.Text = "";
     

    }
    private void eachRecord()
    {
        // showData();
        try
        {
            
            
             
            txtDate.Text = ds.Tables[0].Rows[c].ItemArray[0].ToString();
            txtSalesID.Text = ds.Tables[0].Rows[c].ItemArray[1].ToString();
            //DateTime d1 = DateTime.Parse(ds.Tables[0].Rows[c].ItemArray[2].ToString());
            txtBillingNO.Text = ds.Tables[0].Rows[c].ItemArray[2].ToString();
            ddlCname.Text = ds.Tables[0].Rows[c].ItemArray[3].ToString();
            txtSRNO.Text = ds.Tables[0].Rows[c].ItemArray[4].ToString();
            ddlIem.Text = ds.Tables[0].Rows[c].ItemArray[5].ToString();
            ddlSize.Text = ds.Tables[0].Rows[c].ItemArray[6].ToString();
            txtQuantity.Text = ds.Tables[0].Rows[c].ItemArray[7].ToString();
            txtAmmount.Text = ds.Tables[0].Rows[c].ItemArray[8].ToString();
          
        }
        catch (Exception e1) { }
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {

        try
        {

            cm = new SqlCommand("select * from SALESDETAIL where s_Id=" + int.Parse(txtSalesID.Text), cn);
            SqlDataReader dr = cm.ExecuteReader();
            if (dr.Read())
            {
                 
                txtDate.Text = dr[0].ToString();
                //DateTime d1 = DateTime.Parse(dr[2].ToString());
                txtBillingNO.Text = dr[2].ToString();
                ddlCname.Text = dr[3].ToString();
                txtSRNO.Text = dr[4].ToString();
                ddlIem.Text = dr[5].ToString();
                ddlSize.Text = dr[6].ToString();
                txtQuantity.Text = dr[7].ToString();
                txtAmmount.Text = dr[8].ToString();
           
            }
            else
            {

            }
            dr.Close();
        }
        catch (Exception e11)
        {
            Response.Write(e11.ToString());
        }
    }
    int srNo;
    private void findSrNo()
    {
        try
        {
            cm = new SqlCommand("select max(s_SRNO) from SALESDETAIL where s_Id=" + int.Parse(txtSalesID.Text), cn);
            dr1 = cm.ExecuteReader();
            if (dr1.Read())
            {
                srNo = int.Parse(dr1[0].ToString()) + 1;

            }

            dr1.Close();
        }
        catch (Exception e1)
        {
            srNo = 1;
            //dr1.Close();
        }
        txtSRNO.Text = srNo.ToString();
    }
    //protected void btnshowdate_Click(object sender, EventArgs e)
    //{
         
    //        ds.Clear();
    //        GridView1.DataSource = null;
    //        GridView1.DataBind();
         
    //}


    protected void btnfirst_Click(object sender, EventArgs e)
    {
        //first record
        c = 0;

        eachRecord();
        ViewState["c"] = c.ToString();
    }

    protected void btnnxt_Click(object sender, EventArgs e)
    {
        //next record
        if (c < n - 1)
        {
            c++;

            eachRecord();
            ViewState["c"] = c.ToString();

        }
        else
        {
            Response.Write("<script>alert('Last Record')</script>");
        }
    }

    protected void btnprev_Click(object sender, EventArgs e)
    {
        // previous
        if (c > 0)
        {
            c--;

            eachRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script> alert('First Record');</script>");
        }
    }

    protected void btnist_Click(object sender, EventArgs e)
    {
        //last record

        try
        {
            c = n - 1;

            eachRecord();
            ViewState["c"] = c.ToString();

        }
        catch
        {
            c = n;
        }

    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        showData();
        //if (txtSalesID.Text != "" && txtBillingNO.Text != "" && ddlCname.Text != "" && txtSRNO.Text != "" && ddlIem.Text != "" && ddlSize.Text != "" && txtQuantity.Text != "" && txtAmmount.Text != "" )
        {
            cm = new SqlCommand("insert into  SALESDETAIL  values (@s_Date,@s_Id,@s_No,@s_CName,@s_SRNO,@s_Item,@s_Size,@s_Quantity,@s_Amount)", cn);

            //@d_id,@d_name,@d_dob,@d_age,@d_address,@d_contact,@d_bloodgroup,@d_desease_history
            cm.Parameters.AddWithValue("@s_Date", DateTime.Parse(txtDate.Text));
            cm.Parameters.AddWithValue("@s_Id", txtSalesID.Text);
            cm.Parameters.AddWithValue("@s_No", txtBillingNO.Text);
            cm.Parameters.AddWithValue("@s_CName", ddlCname.Text);
            cm.Parameters.AddWithValue("@s_SRNO", txtSRNO.Text);
            cm.Parameters.AddWithValue("@s_Item", ddlIem.Text);
            cm.Parameters.AddWithValue("@s_Size", ddlSize.Text);
            cm.Parameters.AddWithValue("@s_Quantity", txtQuantity.Text);
            cm.Parameters.AddWithValue("@s_Amount", txtAmmount.Text);
        

            sda.InsertCommand = cm;
            DataRow drw = ds.Tables[0].NewRow();
            //  drw[0] = int.Parse(txtIID.Text);
            drw[0] = DateTime.Parse(txtDate.Text);
            drw[1] = int.Parse(txtSalesID.Text);
            drw[2] = int.Parse(txtBillingNO.Text);
            drw[3] = ddlCname.Text;
            drw[4] = int.Parse(txtSRNO.Text);
            drw[5] = ddlIem.Text;
            drw[6] = int.Parse(ddlSize.Text);
            drw[7] = int.Parse(txtQuantity.Text);
            drw[8] = float.Parse(txtAmmount.Text);
        
            ds.Tables[0].Rows.Add(drw);

            sda.Update(ds.Tables[0]);
            ds.AcceptChanges();
            showData();
            //clear();
            findSrNo();
        }
        //else
        //{
        //    Response.Write("<script>alert('Please fill your information ');</script>");
        //}
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
    }
    protected void btnFinish_Click(object sender, EventArgs e)
    {
       
        Session["SID"] = txtSalesID.Text;
        Session["SDate"] = txtDate.Text;
        Session["Cname"] = ddlCname.Text;
        Session["Amount"] = txtAmmount.Text;

        //Session["Address"] = txtAddress.Text;
        int amt = 0;
        try
        {
            cm = new SqlCommand("select sum(s_Amount) from SALES where s_Id=" + int.Parse(txtSalesID.Text), cn);
            dr1 = cm.ExecuteReader();
            if (dr1.Read())
            {
                amt = int.Parse(dr1[0].ToString());

            }

            dr1.Close();
        }
        catch (Exception e1)
        {

            dr1.Close();
        }
        txtSRNO.Text = srNo.ToString();
        Session["Amount"] = amt.ToString();

        Response.Redirect("frmSale.aspx");
    }
    protected void btnData_Click(object sender, EventArgs e)
    {
        showData1();
    }
    protected void btnCal_Click(object sender, EventArgs e)
    {
        float a = price * int.Parse(txtQuantity.Text);
        txtAmmount.Text = a.ToString();
         
    }
    protected void ddlIem_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {


            cm = new SqlCommand("select * from ITEM where I_Name='" + ddlIem.Text + "'", cn);
            dr1 = cm.ExecuteReader();
            if (dr1.Read())
            {

                price = float.Parse(dr1[7].ToString());
            }
            dr1.Close();
            ViewState["price"] = price.ToString();
        }
        catch (Exception gg)
        {
            dr1.Close();
        }
    }
}