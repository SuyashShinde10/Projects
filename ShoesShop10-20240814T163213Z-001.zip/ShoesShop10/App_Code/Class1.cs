﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Class1
/// </summary>
public class Class1
{
    public string s;
	public Class1()
	{
		//
		// TODO: Add constructor logic here
		//
        s = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\ShoesShop10\App_Data\Table.mdf;Integrated Security=True";
	}
}