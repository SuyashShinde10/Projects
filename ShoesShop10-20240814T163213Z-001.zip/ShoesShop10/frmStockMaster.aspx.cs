﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class frmStockMaster : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    DataSet ds,ds1;
    SqlDataAdapter sda;
    int i, c, n;
    protected void Page_Load(object sender, EventArgs e)
    {
        Class1 x = new Class1();

        cn = new SqlConnection(x.s);
        cn.Open();
        ds = new DataSet();
        ds1 = new DataSet();
        sda = new SqlDataAdapter();
        showData();

    }
    private void showData()
    {
        int p = 0, s = 0;

        //cm = new SqlCommand("select distinct(item_details.i_name ) 'Item' , ( select sum(purchase_details.quantity) from purchase_details where purchase_details.p_item=item_details.i_name  ) - ( select sum( sale_details.quantity) from sale_details where  sale_details.item=item_details.i_name) 'Quantity' from item_details ", cn);

        DataTable dt = new DataTable();

        dt.Columns.Add("Item");
        dt.Columns.Add("Quantity");

        DataTable dt1 = new DataTable();

        cm = new SqlCommand("select distinct(I_Name) from ITEM", cn);
        SqlDataReader dr1 = cm.ExecuteReader();
        dt1.Load(dr1);
        dr1.Close();

        for (int i = 0; i < dt1.Rows.Count; i++)
        {

            DataRow drw = dt.NewRow();
            drw[0] = dt1.Rows[i].ItemArray[0].ToString();

            //Response.Write("<script>alert('" + dt1.Rows[i].ItemArray[0].ToString()  + "');</script>");
            try
            {
                cm = new SqlCommand("select sum(PURCHSEDETAILS.s_Quantity) from PURCHSEDETAILS  where PURCHSEDETAILS.p_Item='" + dt1.Rows[i].ItemArray[0].ToString() + "'", cn);
                dr1 = cm.ExecuteReader();
                if (dr1.Read())
                {
                    p = int.Parse(dr1[0].ToString());
                }
                dr1.Close();

            }
            catch (Exception gg) { p = 0; dr1.Close(); }
            // Response.Write("<script>alert('p= " +p.ToString() + "');</script>");

            try
            {
                cm = new SqlCommand("select sum( SALESDETAILS.s_Quantity) from SALESDETAILS where  SALESDETAILS.s_Item='" + dt1.Rows[i].ItemArray[0].ToString() + "'", cn);
                dr1 = cm.ExecuteReader();
                if (dr1.Read())
                {
                    s = int.Parse(dr1[0].ToString());
                }
                dr1.Close();

            }
            catch (Exception gg) { s = 0; dr1.Close(); }
            //Response.Write("<script>alert('s= " + s.ToString() + "');</script>");


            drw[1] = (p - s).ToString();

            dt.Rows.Add(drw);

        }

        GridView1.DataSource = dt;
        GridView1.DataBind();

    }
    private void showData2()
    {
        ds1.Clear();
        cm = new SqlCommand("select * from ITEM", cn);
        sda.SelectCommand = cm;
        sda.Fill(ds1, "ITEM");
        ds1.AcceptChanges();
        sda.Update(ds1.Tables[0]);

        //n = ds.Tables[0].Rows.Count;

        ddlitem.DataSource = ds1.Tables[0];
        ddlitem.DataTextField = "I_Name";
        ddlitem.DataValueField = "I_Name";
        ddlitem.DataBind();
         

    }
    public void clear()
    {
        txtID.Text = "";
        ddlitem.Text = "";
        ddlsize.Text = "";
        txtquantity.Text = "";
    }
    private void eachRecord()
    {
        // showData();
        try
        {
            txtID.Text = ds.Tables[0].Rows[c].ItemArray[0].ToString();
            //DateTime d1 = DateTime.Parse(ds.Tables[0].Rows[c].ItemArray[2].ToString());
            //txtSdate.Text = ds.Tables[0].Rows[c].ItemArray[1].ToString();

            ddlitem.Text = ds.Tables[0].Rows[c].ItemArray[1].ToString();
            ddlsize.Text = ds.Tables[0].Rows[c].ItemArray[2].ToString();
            txtquantity.Text = ds.Tables[0].Rows[c].ItemArray[3].ToString();

        }
        catch (Exception e1) { }
    }
    protected void btnsearch_Click1(object sender, EventArgs e)
    {
        try
        {

            cm = new SqlCommand("select * from STOCK where s_ID=" + int.Parse(txtID.Text), cn);
            SqlDataReader dr = cm.ExecuteReader();
            if (dr.Read())
            {
                //txtID.Text = dr[1].ToString();
                //DateTime d1 = DateTime.Parse(dr[2].ToString());
                //txtSdate.Text = dr[1].ToString();
                ddlitem.Text = dr[1].ToString();
                ddlsize.Text = dr[2].ToString();
                txtquantity.Text = dr[3].ToString();

            }
            else
            {

            }
            dr.Close();
        }
        catch (Exception e11)
        {
            Response.Write(e11.ToString());
        }

    }


    protected void btnfirst_Click1(object sender, EventArgs e)
    {
        //first record
        c = 0;

        eachRecord();
        ViewState["c"] = c.ToString();
    }

    protected void btnnxt_Click(object sender, EventArgs e)
    {
        //last record
        if (c < n - 1)
        {
            c++;

            eachRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script> alert('Last Record');</script>");

        }
    }

    protected void btnprev_Click(object sender, EventArgs e)
    {
        // previous
        if (c > 0)
        {
            c--;

            eachRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script> alert('First Record');</script>");
        }
    }

    protected void btnist_Click(object sender, EventArgs e)
    {
        
        //Last record
        try
        {
            c = n - 1;


            eachRecord();
            ViewState["c"] = c.ToString();
        }
        catch
        {
            c = n;
        }

    }
    //protected void btnshowdate_Click1(object sender, EventArgs e)
    //{

    //    ds.Clear();
    //    GridView1.DataSource = null;
    //    GridView1.DataBind();
    //}

    protected void btnadd_Click(object sender, EventArgs e)
    {
        showData();
        if (txtID.Text != "" && ddlitem.Text != "" && ddlsize.Text != "" && txtquantity.Text != "")
        {
            cm = new SqlCommand("insert into STOCK values(@s_ID,@s_Item,@s_Size,@s_Quantity)", cn);

            //@d_id,@d_name,@d_dob,@d_age,@d_address,@d_contact,@d_bloodgroup,@d_desease_history
            //cm.Parameters.AddWithValue("@s_Date", txtID.Text);
            cm.Parameters.AddWithValue("@s_ID", txtID.Text);
            cm.Parameters.AddWithValue("@s_Item", ddlitem.Text);
            cm.Parameters.AddWithValue("@s_Size", ddlsize.Text);
            cm.Parameters.AddWithValue("@s_Quantity", txtquantity.Text);


            sda.InsertCommand = cm;
            DataRow drw = ds.Tables[0].NewRow();
            drw[0] = int.Parse(txtID.Text);
            //drw[1] = txtSdate.Text;
            drw[1] = ddlitem.Text;
            drw[2] = int.Parse(ddlsize.Text);
            drw[3] = int.Parse(txtquantity.Text);
            ds.Tables[0].Rows.Add(drw);

            sda.Update(ds.Tables[0]);
            ds.AcceptChanges();
            showData();
            clear();
        }
        else
        {
            Response.Write("<script>alert('Please fill your information ');</script>");
        }
    }
    protected void btnedit0_Click(object sender, EventArgs e)
    {
        cm = new SqlCommand("update STOCK set s_Item=@s_Item,s_Size=@s_Size,s_Quantity=@s_Quantity where s_ID=@s_ID", cn);

        //@d_id,@d_name,@d_dob,@d_age,@d_address,@d_contact,@d_bloodgroup,@d_desease_history
        //cm.Parameters.AddWithValue("@s_Date", txtID.Text);

        cm.Parameters.AddWithValue("@s_ID", txtID.Text);
        cm.Parameters.AddWithValue("@s_Item", ddlitem.Text);
        cm.Parameters.AddWithValue("@s_Size", ddlsize.Text);
        cm.Parameters.AddWithValue("@s_Quantity", txtquantity.Text);


        sda.UpdateCommand = cm;
        DataRow[] drw = ds.Tables[0].Select(String.Format("s_ID=" + int.Parse(txtID.Text)));
        //drw[0][0] = int.Parse(txtID.Text);
        //drw[0][1] = txtSdate.Text;
        drw[0][1] = ddlitem.Text;
        drw[0][2] = int.Parse(ddlsize.Text);
        drw[0][3] = int.Parse(txtquantity.Text);

        

        sda.Update(ds.Tables[0]);
        ds.AcceptChanges();
        showData();
        clear();
    }

    protected void btndelete0_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from  STOCK where s_ID=@s_ID", cn);

            //@d_id,@d_name,@d_dob,@d_age,@d_address,@d_contact,@d_bloodgroup,@d_desease_history
            cm.Parameters.AddWithValue("@s_ID", txtID.Text);

            sda.DeleteCommand = cm;
            DataRow[] drw = ds.Tables[0].Select(String.Format("s_ID=" + int.Parse(txtID.Text)));
            drw[0][0] = int.Parse(txtID.Text);

            ds.Tables[0].Rows[0].Delete();
            sda.Update(ds.Tables[0]);
            ds.AcceptChanges();
            showData();
            clear();
        }
        catch (Exception e1) { }
        }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        clear();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
    }
    protected void ddlitem_SelectedIndexChanged(object sender, EventArgs e)
    {
        int p = 0, s = 0;
        SqlDataReader dr2 = null;
        try
        {
            cm = new SqlCommand("select sum(PURCHSEDETAILS.s_Quantity) from PURCHSEDETAILS  where PURCHSEDETAILS.p_Item='" + ddlitem.Text + "'", cn);
            dr2 = cm.ExecuteReader();
            if (dr2.Read())
            {
                p = int.Parse(dr2[0].ToString());
            }
            dr2.Close();

        }
        catch (Exception gg) { p = 0; dr2.Close(); }
        //Response.Write("<script>alert('p= " + p.ToString() + "');</script>");

        try
        {
            cm = new SqlCommand("select sum( SALESDETAILS.s_Quantity) from SALESDETAILS where  SALESDETAILS.s_Item='" + ddlitem.Text + "'", cn);
            dr2 = cm.ExecuteReader();
            if (dr2.Read())
            {
                s = int.Parse(dr2[0].ToString());
            }
            dr2.Close();

        }
        catch (Exception gg) { s = 0; dr2.Close(); }
        txtquantity.Text = (p - s).ToString();

        try
        {
            cm = new SqlCommand("select I_Code from ITEM where  I_Name='" + ddlitem.Text + "'", cn);
            dr2 = cm.ExecuteReader();
            if (dr2.Read())
            {
                ddlsize.Text = dr2[0].ToString();
            }
            dr2.Close();

        }
        catch (Exception gg)
        {
            ddlsize.Text = "";
            dr2.Close();
        }
         
    }

    protected void btnItem_Click(object sender, EventArgs e)
    {
        showData2();
    }
}

