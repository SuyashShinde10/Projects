﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class frmCustomerMaster : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    DataSet ds;
    SqlDataAdapter sda;
    int i, c, n;
    protected void Page_Load(object sender, EventArgs e)
    {
        Class1 x = new Class1();

        cn = new SqlConnection(x.s);
        cn.Open();
        ds = new DataSet();
        sda = new SqlDataAdapter();
        showData();
    }
    private void showData()
    {
        ds.Clear();
        cm = new SqlCommand("select * from CUSTOMER", cn);
        sda.SelectCommand = cm;
        sda.Fill(ds, "CUSTOMER");
        ds.AcceptChanges();
        sda.Update(ds.Tables[0]);

        n = ds.Tables[0].Rows.Count;

        GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();

    }
    public void clear()
    {
        txtCId.Text = "";
        txtCname.Text = "";
        txtCNo.Text = "";
        txtEmail.Text = "";
    }
    private void eachRecord()
    {
        // showData();
        try
        {
            txtCId.Text = ds.Tables[0].Rows[c].ItemArray[0].ToString();
            txtCname.Text = ds.Tables[0].Rows[c].ItemArray[1].ToString();
            //DateTime d1 = DateTime.Parse(ds.Tables[0].Rows[c].ItemArray[2].ToString());
            txtCNo.Text = ds.Tables[0].Rows[c].ItemArray[2].ToString();
            txtEmail.Text = ds.Tables[0].Rows[c].ItemArray[3].ToString();
            
        }
        catch (Exception e1) { }
    }
    //protected void TextBox4_TextChanged(object sender, EventArgs e)
    //{

    //}
    //protected void btnshowdate_Click(object sender, EventArgs e)
    //{
    //    showData();
    //}

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        try
        {

            cm = new SqlCommand("select * from CUSTOMER where cus_ID=" + int.Parse(txtCId.Text), cn);
            SqlDataReader dr = cm.ExecuteReader();
            if (dr.Read())
            {
                //txtCId.Text = dr[1].ToString();
                //DateTime d1 = DateTime.Parse(dr[2].ToString());
                txtCname.Text = dr[1].ToString();
                txtCNo.Text = dr[2].ToString();
                txtEmail.Text = dr[3].ToString();

            }
            else
            {

            }
            dr.Close();
        }
        catch (Exception e11)
        {
            Response.Write(e11.ToString());
        }
    }
    protected void btnfirst_Click(object sender, EventArgs e)
    {
        //first record
        c = 0;

        eachRecord();
        ViewState["c"] = c.ToString();

    }

    protected void btnnxt_Click(object sender, EventArgs e)
    {
        //next record
        if (c < n - 1)
        {
            c++;

            eachRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script> alert('Last Record');</script>");

        }
    }

    protected void btnprev_Click(object sender, EventArgs e)
    {
        // previous
        if (c > 0)
        {
            c--;

            eachRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script> alert('First Record');</script>");
        }
    }

    protected void btnist_Click(object sender, EventArgs e)
    {
        //Last record
        try
        {
            c = n - 1;


            eachRecord();
            ViewState["c"] = c.ToString();
        }
        catch
        {
            c = n;
        }
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        showData();
        if (txtCId.Text != "" && txtCname.Text != "" && txtCNo.Text != "" && txtEmail.Text != "")
        {
            try
            {
                cm = new SqlCommand("insert into CUSTOMER values(@Cus_ID,@Cus_Name,@Cus_No,@Cus_Eid)", cn);

                //@d_id,@d_name,@d_dob,@d_age,@d_address,@d_contact,@d_bloodgroup,@d_desease_history
                cm.Parameters.AddWithValue("@Cus_ID", txtCId.Text);
                cm.Parameters.AddWithValue("@Cus_Name", txtCname.Text);
                cm.Parameters.AddWithValue("@Cus_No", txtCNo.Text);
                cm.Parameters.AddWithValue("@Cus_Eid", txtEmail.Text);


                sda.InsertCommand = cm;
                DataRow drw = ds.Tables[0].NewRow();
                drw[0] = int.Parse(txtCId.Text);
                drw[1] = txtCname.Text;
                drw[2] = int.Parse(txtCNo.Text);
                drw[3] = txtEmail.Text;
                ds.Tables[0].Rows.Add(drw);


                sda.Update(ds.Tables[0]);
                ds.AcceptChanges();
                showData();
                clear();
            }
            catch (Exception e1) { }
        }
        else
        {
            Response.Write("<script>alert('Please fill your information ');</script>");
        }
    }

    protected void btnedit0_Click(object sender, EventArgs e)
    {
        //try
        //{
            cm = new SqlCommand("update CUSTOMER set Cus_Name=@Cus_Name,Cus_No=@Cus_No,Cus_Eid=@Cus_Eid  where Cus_ID=@Cus_ID", cn);

            //@d_id,@d_name,@d_dob,@d_age,@d_address,@d_contact,@d_bloodgroup,@d_desease_history
            cm.Parameters.AddWithValue("@Cus_ID", txtCId.Text);
            cm.Parameters.AddWithValue("@Cus_Name", txtCname.Text);
            cm.Parameters.AddWithValue("@Cus_No", txtCNo.Text);
            cm.Parameters.AddWithValue("@Cus_Eid", txtEmail.Text);


            sda.UpdateCommand = cm;
            DataRow[] drw = ds.Tables[0].Select(String.Format("Cus_ID=" + int.Parse(txtCId.Text)));
            drw[0][0] = int.Parse(txtCId.Text);
            drw[0][1] = txtCname.Text;
            drw[0][2] = int.Parse(txtCNo.Text);
            drw[0][3] = txtEmail.Text;


            sda.Update(ds.Tables[0]);
            ds.AcceptChanges();
            showData();
            clear();
        //}
        //catch (Exception e1) { }
    }

    protected void btndelete0_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from CUSTOMER where Cus_id=@Cus_id", cn);

            //@d_id,@d_name,@d_dob,@d_age,@d_address,@d_contact,@d_bloodgroup,@d_desease_history
            cm.Parameters.AddWithValue("@Cus_id", txtCId.Text);

            sda.DeleteCommand = cm;
            DataRow[] drw = ds.Tables[0].Select(String.Format("Cus_id=" + int.Parse(txtCId.Text)));
            drw[0][0] = int.Parse(txtCId.Text);

            ds.Tables[0].Rows[0].Delete();
            sda.Update(ds.Tables[0]);
            ds.AcceptChanges();
            showData();
            clear();
        }
        catch (Exception e1) { }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        clear();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
    }
}
