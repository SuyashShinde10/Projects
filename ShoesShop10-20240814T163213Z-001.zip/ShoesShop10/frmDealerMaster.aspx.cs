﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class frmDealerMaster : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    DataSet ds;
    SqlDataAdapter sda;
    int i, c, n;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
        else
        {
            c = 0;

        }
        Class1 x = new Class1();

        cn = new SqlConnection(x.s);
        cn.Open();
        ds = new DataSet();
        sda = new SqlDataAdapter();
        showData();
    }
    private void showData()
    {
        ds.Clear();
        cm = new SqlCommand("select * from DEALER", cn);
        sda.SelectCommand = cm;
        sda.Fill(ds, "DEALER");
        ds.AcceptChanges();
        sda.Update(ds.Tables[0]);

        n = ds.Tables[0].Rows.Count;

        GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();

    }
    public void clear()
    {
        txtID.Text = "";
        txtDname.Text = "";
        txtaddress.Text = "";
        txtEID.Text = "";
        txtCno1.Text = "";
        txtCno2.Text = "";
        txtEID.Text = "";
        txtUPI.Text = "";
        txtGST.Text = "";
        txtBName.Text = "";
        txtIFSC.Text = "";
        txtAccNO.Text = "";
    }
    private void eachRecord()
    {
        // showData();
        try
        {
            txtID.Text = ds.Tables[0].Rows[c].ItemArray[0].ToString();
            //DateTime d1 = DateTime.Parse(ds.Tables[0].Rows[c].ItemArray[1].ToString());
            txtDname.Text = ds.Tables[0].Rows[c].ItemArray[1].ToString();

            txtaddress.Text = ds.Tables[0].Rows[c].ItemArray[2].ToString();
            txtCno1.Text = ds.Tables[0].Rows[c].ItemArray[3].ToString();
            txtCno2.Text = ds.Tables[0].Rows[c].ItemArray[4].ToString();
            txtEID.Text = ds.Tables[0].Rows[c].ItemArray[5].ToString();

            txtUPI.Text = ds.Tables[0].Rows[c].ItemArray[6].ToString();
            txtGST.Text = ds.Tables[0].Rows[c].ItemArray[7].ToString();
            txtBName.Text = ds.Tables[0].Rows[c].ItemArray[8].ToString();
            txtIFSC.Text = ds.Tables[0].Rows[c].ItemArray[9].ToString();
            txtAccNO.Text = ds.Tables[0].Rows[c].ItemArray[10].ToString();
        }
        catch (Exception e1) { }
    }
    
    

    
    //protected void btnShowDate0_Click(object sender, EventArgs e)
    //{
    //    ds.Clear();
    //    GridView1.DataSource = null;
    //    GridView1.DataBind();
    //}
    

    protected void btnsearch_Click1(object sender, EventArgs e)
    {

        try
        {

            cm = new SqlCommand("Select * from DEALER where D_Id=" + int.Parse(txtID.Text), cn);
            SqlDataReader dr = cm.ExecuteReader();
            if (dr.Read())
            {
                //txtID.Text = dr[1].ToString();
                //DateTime d1 = DateTime.Parse(dr[2].ToString());
                txtDname.Text = dr[1].ToString();
                txtaddress.Text = dr[2].ToString();
                txtCno1.Text = dr[3].ToString();
                txtCno2.Text = dr[4].ToString();
                txtEID.Text = dr[5].ToString();
                txtUPI.Text = dr[6].ToString();
                txtGST.Text = dr[7].ToString();
                txtBName.Text = dr[8].ToString();
                txtIFSC.Text = dr[9].ToString();
                txtAccNO.Text = dr[10].ToString();
            }
            else
            {

            }
            dr.Close();
        }
        catch (Exception e11)
        {
            Response.Write(e11.ToString());
        }

    }
    protected void btnfirst_Click1(object sender, EventArgs e)
    {
        //first record
        c = 0;

        eachRecord();
        ViewState["c"] = c.ToString();
    }
    protected void btnshowdate_Click1(object sender, EventArgs e)
    {
        showData();
    }
    protected void btnnxt_Click1(object sender, EventArgs e)
    {
        //next record
        if (c < n - 1)
        {
            c++;

            eachRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script> alert('Last Record');</script>");

        }
    }
    protected void btnist_Click(object sender, EventArgs e)
    {
        //Last record
        try
        {
            c = n - 1;


            eachRecord();
            ViewState["c"] = c.ToString();
        }
        catch
        {
            c = n;
        }
    }
    protected void btnprev_Click(object sender, EventArgs e)
    {
        // previous
        if (c > 0)
        {
            c--;

            eachRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script> alert('First Record');</script>");
        }
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        showData();
        if (txtID.Text != "" && txtDname.Text != "" && txtaddress.Text != "" && txtCno1.Text != "" && txtCno2.Text != "" && txtEID.Text != "" && txtUPI.Text != "" && txtGST.Text != "" && txtBName.Text != "" && txtIFSC.Text != "" && txtAccNO.Text != "" )
        {
            cm = new SqlCommand("insert into DEALER values(@D_Id,@D_Name,@D_Adress,@D_No,@D_No2,@D_EId,@D_UPIId,@D_GST,@B_Name,@B_IFSC,@B_AccNo)", cn);

            //@d_id,@d_name,@d_dob,@d_age,@d_address,@d_contact,@d_bloodgroup,@d_desease_history
            cm.Parameters.AddWithValue("@D_Id", txtID.Text);
            cm.Parameters.AddWithValue("@D_Name", txtDname.Text);
            cm.Parameters.AddWithValue("@D_Adress", txtaddress.Text);
            cm.Parameters.AddWithValue("@D_No", txtCno1.Text);
            cm.Parameters.AddWithValue("@D_No2", txtCno2.Text);
            cm.Parameters.AddWithValue("@D_EId", txtEID.Text);
            cm.Parameters.AddWithValue("@D_UPIId", txtUPI.Text);
            cm.Parameters.AddWithValue("@D_GST", txtGST.Text);
            cm.Parameters.AddWithValue("@B_Name", txtBName.Text);
            cm.Parameters.AddWithValue("@B_IFSC", txtIFSC.Text);
            cm.Parameters.AddWithValue("@B_AccNo", txtAccNO.Text);


            sda.InsertCommand = cm;
            DataRow drw = ds.Tables[0].NewRow();
            drw[0] = long.Parse(txtID.Text);
            drw[1] = txtDname.Text;
            drw[2] = txtaddress;
            drw[3] = long.Parse(txtCno1.Text);
            drw[4] = long.Parse(txtCno2.Text);
            drw[5] = txtEID.Text;
            drw[6] = long.Parse(txtUPI.Text);
            drw[7] = float.Parse(txtGST.Text);
            drw[8] = txtBName.Text;
            drw[9] = long.Parse(txtIFSC.Text);
            drw[10] = long.Parse(txtAccNO.Text);
            ds.Tables[0].Rows.Add(drw);

            sda.Update(ds.Tables[0]);
            ds.AcceptChanges();
            showData();
            clear();
        }
        else
        {
            Response.Write("<script>alert('Please fill your information ');</script>");
        }
    }

    protected void btnedit_Click(object sender, EventArgs e)
    {
        cm = new SqlCommand("update DEALER set D_name=@D_name,D_Adress=@D_Adress,D_No=@D_No,D_No2=@D_No2,D_Eid=@D_Eid,D_UPIid=@D_UPIid,D_GST=@D_GST,B_Name=@B_Name,B_IFSC=@B_IFSC,B_AccNo=@B_AccNo where D_Id=@D_Id", cn);

        //@d_id,@d_name,@d_dob,@d_age,@d_address,@d_contact,@d_bloodgroup,@d_desease_history
        cm.Parameters.AddWithValue("@D_Id", txtID.Text);
        cm.Parameters.AddWithValue("@D_Name", txtDname.Text);
        cm.Parameters.AddWithValue("@D_Adress", txtaddress.Text);
        cm.Parameters.AddWithValue("@D_No", txtCno1.Text);
        cm.Parameters.AddWithValue("@D_No2", txtCno2.Text);
        cm.Parameters.AddWithValue("@D_Eid", txtEID.Text);
        cm.Parameters.AddWithValue("@D_UPIid", txtUPI.Text);
        cm.Parameters.AddWithValue("@D_GST", txtGST.Text);
        cm.Parameters.AddWithValue("@B_Name", txtBName.Text);
        cm.Parameters.AddWithValue("@B_IFSC", txtIFSC.Text);
        cm.Parameters.AddWithValue("@B_AccNo", txtAccNO.Text);

        sda.UpdateCommand = cm;
        DataRow[] drw = ds.Tables[0].Select(String.Format("D_Id=" + int.Parse(txtID.Text)));
        drw[0][0] = int.Parse(txtID.Text);
        drw[0][1] = txtDname.Text;
        drw[0][2] = txtaddress;
        drw[0][3] = int.Parse(txtCno1.Text);
        drw[0][4] = int.Parse(txtCno2.Text);
        drw[0][5] = txtEID.Text;
        drw[0][6] = int.Parse(txtUPI.Text);
        drw[0][7] = float.Parse(txtGST.Text);
        drw[0][8] = txtBName.Text;
        drw[0][9] = int.Parse(txtIFSC.Text);
        drw[0][10] = int.Parse(txtAccNO.Text);
        //ds.Tables[0].Rows.Add(drw);

        sda.Update(ds.Tables[0]);
        ds.AcceptChanges();
        showData();
        clear();
    }

    protected void btndelete_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from DEALER where D_Id=@D_Id", cn);

            //@d_id,@d_name,@d_dob,@d_age,@d_address,@d_contact,@d_bloodgroup,@d_desease_history
            cm.Parameters.AddWithValue("@D_id", txtID.Text);

            sda.DeleteCommand = cm;
            DataRow[] drw = ds.Tables[0].Select(String.Format("D_Id=" + int.Parse(txtID.Text)));
            drw[0][0] = int.Parse(txtID.Text);

            ds.Tables[0].Rows[0].Delete();
            sda.Update(ds.Tables[0]);
            ds.AcceptChanges();
            showData();
            clear();
        }
        catch (Exception e1) { }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        clear();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
    }
}
