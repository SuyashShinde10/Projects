﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Purchase : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    DataSet ds,ds1,ds2;
    SqlDataAdapter sda;
    int i, c, n;
    float price;
    SqlDataReader dr;
    protected void Page_Load(object sender, EventArgs e)
    {
        txtDate.Text = DateTime.Now.ToShortDateString();
        try
        {
            txtPID.Text = Session["purId"].ToString();
            txtDate.Text = Session["Date"].ToString();
            ddlCompany.Text = Session["CompName"].ToString();
            txtTAmmount.Text = Session["Amount"].ToString();
             
        }
        catch (Exception tt)
        { }
        if (ViewState["price"] != null)
        {
            price = float.Parse(ViewState["price"].ToString());

        }
        else
        {
            price = 0;
        }
        Class1 x = new Class1();

        cn = new SqlConnection(x.s);
         
        cn.Open();
        ds = new DataSet();
        ds1 = new DataSet();
        ds2 = new DataSet();
        sda = new SqlDataAdapter();
        showData();
        showData1();
        
    }
    private void showData1()
    {
        ds1.Clear();
        cm = new SqlCommand("select * from DEALER", cn);
        sda.SelectCommand = cm;
        sda.Fill(ds1, "DEALER");
        ds1.AcceptChanges();
        sda.Update(ds1.Tables[0]);

        ddlCompany.DataSource = ds1.Tables[0];
        ddlCompany.DataTextField = "D_Name";
        ddlCompany.DataValueField = "D_Name";

        ddlCompany.DataBind();

    }
    //private void showData2()
    //{
    //    ds2.Clear();
    //    cm = new SqlCommand("select * from ITEM", cn);
    //    sda.SelectCommand = cm;
    //    sda.Fill(ds2, "ITEM");
    //    ds2.AcceptChanges();
    //    sda.Update(ds2.Tables[0]);

    //    //n = ds.Tables[0].Rows.Count;

    //    ddlCompany.DataSource = ds2.Tables[0];
    //    ddlCompany.DataTextField = "I_Name";
    //    ddlCompany.DataValueField = "I_Name";

    //    ddlCompany.DataBind();

    //}
    private void showData()
    {
        ds.Clear();
        cm = new SqlCommand("select * from PURCHASE", cn);
        sda.SelectCommand = cm;
        sda.Fill(ds, "PURCHASE");
        ds.AcceptChanges();
        sda.Update(ds.Tables[0]);

        n = ds.Tables[0].Rows.Count;

        GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();

    }
    public void clear()
    {
        txtPID.Text = "";
        txtBillNO.Text = "";
        //ddlCompany.Text = ""; 
        txtTAmmount.Text = "";
        txtGST.Text = "";
        txtActAmm.Text = "";

    }
    private void eachRecord()
    {
        // showData();
        try
        {
            txtDate.Text = ds.Tables[0].Rows[c].ItemArray[0].ToString();
            
            //DateTime d1 = DateTime.Parse(ds.Tables[0].Rows[c].ItemArray[0].ToString());
            txtPID.Text = ds.Tables[0].Rows[c].ItemArray[1].ToString();
            txtBillNO.Text = ds.Tables[0].Rows[c].ItemArray[2].ToString();
            ddlCompany.Text = ds.Tables[0].Rows[c].ItemArray[3].ToString();
            txtTAmmount.Text = ds.Tables[0].Rows[c].ItemArray[4].ToString();
            txtGST.Text = ds.Tables[0].Rows[c].ItemArray[5].ToString();
            txtActAmm.Text = ds.Tables[0].Rows[c].ItemArray[6].ToString();
            
        }
        catch (Exception e1) { }
    }

    protected void btnfirst_Click(object sender, EventArgs e)
    {
        //first record
        c = 0;

        eachRecord();
        ViewState["c"] = c.ToString();

    }
    protected void btnprev_Click(object sender, EventArgs e)
    {
        // previous
        if (c > 0)
        {
            c--;

            eachRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script> alert('First Record');</script>");
        }
    }

    protected void btnnxt_Click(object sender, EventArgs e)
    {
        //next record
        if (c < n - 1)
        {
            c++;

            eachRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script> alert('Last Record');</script>");

        }
    }

    protected void btnist_Click(object sender, EventArgs e)
    {
        //Last record
        try
        {
            c = n - 1;


            eachRecord();
            ViewState["c"] = c.ToString();
        }
        catch
        {
            c = n;
        }
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        showData();
        if (txtDate.Text != "" && txtPID.Text != "" && txtBillNO.Text != "" && ddlCompany.Text != "" && txtTAmmount.Text != "" && txtGST.Text != "" && txtActAmm.Text != "")
        {
        cm = new SqlCommand("insert into  PURCHASE  values (@P_Date,@P_Id,@P_Bno,@P_Cname,@P_Amount,@P_GST,@P_ActualAmount)", cn);

        //@d_id,@d_name,@d_dob,@d_age,@d_address,@d_contact,@d_bloodgroup,@d_desease_history
        //cm.Parameters.AddWithValue("@P_Date", txtDate.Text);
        cm.Parameters.AddWithValue("@P_Date", DateTime.Parse(txtDate.Text));
        cm.Parameters.AddWithValue("@P_Id", txtPID.Text);
        cm.Parameters.AddWithValue("@P_Bno", txtBillNO.Text);
        cm.Parameters.AddWithValue("@P_Cname", ddlCompany.Text);
        cm.Parameters.AddWithValue("@P_Amount", txtTAmmount.Text);
        cm.Parameters.AddWithValue("@P_GST", txtGST.Text);
        cm.Parameters.AddWithValue("@P_ActualAmount", txtActAmm.Text);
         

        sda.InsertCommand = cm;
        DataRow drw = ds.Tables[0].NewRow();
        drw[0] = DateTime.Parse(txtDate.Text);
        drw[1] = int.Parse(txtPID.Text);
        drw[2] = int.Parse(txtBillNO.Text);
        drw[3] = ddlCompany.Text;
        drw[4] = float.Parse(txtTAmmount.Text);
        drw[5] = float.Parse(txtGST.Text);
        drw[6] = float.Parse(txtActAmm.Text);
        ds.Tables[0].Rows.Add(drw);

        sda.Update(ds.Tables[0]);
        ds.AcceptChanges();
        showData();
        clear();
        }
        else
        {
            Response.Write("<script>alert('Please fill your information ');</script>");
        }
    }
    protected void btnedit0_Click(object sender, EventArgs e)
    {
        cm = new SqlCommand("update PURCHASE set P_Date=P_Date,@P_Bno=@P_Bno,P_Cname=@P_Cname,P_Amount=@P_Amount,P_GST=@P_GST,P_ActualAmount=@P_ActualAmount where P_Id=@P_Id", cn);

        //@d_id,@d_name,@d_dob,@d_age,@d_address,@d_contact,@d_bloodgroup,@d_desease_history
        cm.Parameters.AddWithValue("@P_Date", DateTime.Parse(txtDate.Text));
        cm.Parameters.AddWithValue("@P_Id", txtPID.Text);
        cm.Parameters.AddWithValue("@P_Bno", txtBillNO.Text);
        cm.Parameters.AddWithValue("@P_Cname", ddlCompany.Text);
        cm.Parameters.AddWithValue("@P_Amount", txtTAmmount.Text);
        cm.Parameters.AddWithValue("@P_GST", txtGST.Text);
        cm.Parameters.AddWithValue("@P_ActualAmount", txtActAmm.Text);

        sda.UpdateCommand = cm;
        DataRow[] drw = ds.Tables[0].Select(String.Format("P_Id=" + int.Parse(txtPID.Text)));
        drw[0][0] = DateTime.Parse(txtDate.Text);
        drw[0][1] = int.Parse(txtPID.Text);
        drw[0][2] = int.Parse(txtBillNO.Text);
        drw[0][3] = ddlCompany.Text;
        drw[0][4] = float.Parse(txtTAmmount.Text);
        drw[0][5] = float.Parse(txtGST.Text);
        drw[0][6] = float.Parse(txtActAmm.Text);


        sda.Update(ds.Tables[0]);
        ds.AcceptChanges();
        showData();
        clear();
    }

    protected void btndelete0_Click(object sender, EventArgs e)
    {
        //cm = new SqlCommand("delete from PURCHASE ", cn);
        //cm.ExecuteNonQuery();
        try
        {
            cm = new SqlCommand("delete from PURCHASE where P_Id=@P_Id", cn);

            //@d_id,@d_name,@d_dob,@d_age,@d_address,@d_contact,@d_bloodgroup,@d_desease_history
            cm.Parameters.AddWithValue("@P_Id", txtPID.Text);

            sda.DeleteCommand = cm;
            DataRow[] drw = ds.Tables[0].Select(String.Format("P_Id=" + int.Parse(txtPID.Text)));
            drw[0][0] = int.Parse(txtPID.Text);

            ds.Tables[0].Rows[0].Delete();
            sda.Update(ds.Tables[0]);
            ds.AcceptChanges();
            showData();
            clear();
        }
        catch (Exception e1) { }
    }
    protected void btnsearch0_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("Select * from  PURCHASE where P_Id=" + int.Parse(txtPID.Text), cn);
            SqlDataReader dr = cm.ExecuteReader();
            if (dr.Read())
            {
                //txtname.Text = dr[1].ToString();
                //DateTime d1 = DateTime.Parse(dr[1].ToString());
                txtDate.Text = dr[0].ToString();
                
                txtBillNO.Text = dr[2].ToString();

                ddlCompany.Text = dr[3].ToString();
                txtTAmmount.Text = dr[4].ToString();
                txtGST.Text = dr[5].ToString();
                txtActAmm.Text = dr[6].ToString();
            }
            else
            {

            }
            dr.Close();
        }
        catch (Exception e11)
        {
            Response.Write(e11.ToString());
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        clear();
    }
    protected void btnOK_Click(object sender, EventArgs e)
    {
        Session["purId"] = txtPID.Text;
        Session["Date"] = txtDate.Text;
        Session["CompName"] = ddlCompany.Text;
        Session["TAmount"] = txtTAmmount.Text;
        Response.Redirect("frmPurchaseDetails.aspx");
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
    }
    protected void btnCompany_Click(object sender, EventArgs e)
    {
        showData1();
        //showData2();
    }
}
