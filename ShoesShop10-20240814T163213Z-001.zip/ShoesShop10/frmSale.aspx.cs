﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class frmSale : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    DataSet ds,ds1,ds2;
    SqlDataAdapter sda;
    int i, c, n;
    float price;
    SqlDataReader dr;
    protected void Page_Load(object sender, EventArgs e)
    {
        txtSDate.Text = DateTime.Now.ToShortDateString();
        try
        {
            txtsID.Text = Session["SID"].ToString();
            txtSDate.Text = Session["SDate"].ToString();
            ddlCname.Text = Session["Cname"].ToString();
            txtAmm.Text = Session["Amount"].ToString();
            //txtAmount.Text = Session["Amount"].ToString();
        }
        catch (Exception tt)
        { }
        if (ViewState["price"] != null)
        {
            price = float.Parse(ViewState["price"].ToString());

        }
        else
        {
            price = 0;
        }
        Class1 x = new Class1();
        cn = new SqlConnection(x.s);
        cn.Open();
        ds = new DataSet();
        ds1 = new DataSet();
        ds2 = new DataSet();
        sda = new SqlDataAdapter();
        showData();
        showData2();
    }
    private void showData()
    {
        ds.Clear();
        cm = new SqlCommand("select * from SALES", cn);
        sda.SelectCommand = cm;
        sda.Fill(ds, "SALES");
        ds.AcceptChanges();
        sda.Update(ds.Tables[0]);

        n = ds.Tables[0].Rows.Count;

        GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();

    }
     
    public void showData2()
    {
        ds2.Clear();

        cm = new SqlCommand("select * from CUSTOMER", cn);
        sda.SelectCommand = cm;
        sda.Fill(ds2, "CUSTOMER");
        ds2.AcceptChanges();
        sda.Update(ds2.Tables[0]);

        //n = ds.Tables[0].Rows.Count;

        ddlCname.DataSource = ds2.Tables[0];
        ddlCname.DataTextField = "Cus_Name";
        ddlCname.DataValueField = "Cus_Name";

        ddlCname.DataBind();

    }
    public void clear()
    {
        txtsID.Text = "";
        txtbillno.Text = "";
        //ddlCname.Text = "";
        txtAmm.Text = "";
        txtGST.Text = "";
        txtActAmm.Text = "";
         

    }
    private void eachRecord()
    {
        // showData();
        try
        {
            
            //DateTime d1 = DateTime.Parse(ds.Tables[0].Rows[c].ItemArray[0].ToString());
            txtSDate.Text = ds.Tables[0].Rows[c].ItemArray[0].ToString();
            txtsID.Text = ds.Tables[0].Rows[c].ItemArray[1].ToString();
            txtbillno.Text = ds.Tables[0].Rows[c].ItemArray[2].ToString();
            ddlCname.Text = ds.Tables[0].Rows[c].ItemArray[3].ToString();
            txtAmm.Text = ds.Tables[0].Rows[c].ItemArray[4].ToString();
            txtGST.Text = ds.Tables[0].Rows[c].ItemArray[5].ToString();
            txtActAmm.Text = ds.Tables[0].Rows[c].ItemArray[6].ToString();
             
        }
        catch (Exception e1) { }
    }
    protected void btnOK_Click(object sender, EventArgs e)
    {
        Session["sID"] = txtsID.Text;
        Session["SDate"] = txtSDate.Text;
        Session["Cname"] = ddlCname.Text;
        Session["Amount"] = txtAmm.Text;

        Response.Redirect("~/frmSalesDetails.aspx");
        //Response.Redirect("frmSalesDetails.aspx");
    }
    protected void btnfirst_Click(object sender, EventArgs e)
    {
        //first record
        c = 0;

        eachRecord();
        ViewState["c"] = c.ToString();

    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        // showData();
        try
        {

            cm = new SqlCommand("Select * from SALES where s_Id=" + int.Parse(txtsID.Text), cn);
            SqlDataReader dr = cm.ExecuteReader();
            if (dr.Read())
            {
                //txtsID.Text = dr[1].ToString();
                //DateTime d1 = DateTime.Parse(dr[0].ToString());
                txtSDate.Text = dr[0].ToString();
                txtbillno.Text = dr[2].ToString();
                ddlCname.Text = dr[3].ToString();
                txtAmm.Text = dr[4].ToString();
                txtGST.Text = dr[5].ToString();
                txtActAmm.Text = dr[6].ToString();
            }
            else
            {

            }
            dr.Close();
        }
        catch (Exception e11)
        {
            Response.Write(e11.ToString());
        }
    }

    protected void btnnxt_Click(object sender, EventArgs e)
    {

        //last record
        if (c < n - 1)
        {
            c++;

            eachRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script> alert('Last Record');</script>");

        }
    }

    protected void btnprev_Click(object sender, EventArgs e)
    {
        // previous
        if (c > 0)
        {
            c--;

            eachRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script> alert('First Record');</script>");
        }
    }

    protected void btnist_Click(object sender, EventArgs e)
    {
        //Last record
        try
        {
            c = n - 1;


            eachRecord();
            ViewState["c"] = c.ToString();
        }
        catch
        {
            c = n;
        }
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        showData();
        if (txtSDate.Text != "" && txtsID.Text != "" && txtbillno.Text != "" && ddlCname.Text != "" && txtAmm.Text != "" && txtGST.Text != "" && txtActAmm.Text != "")
        {
            cm = new SqlCommand("insert into SALES values(@s_Date,@s_Id,@s_BNo,@s_Cname,@s_TAmount,@s_GST,@s_ATAmount)", cn);

            //@d_id,@d_name,@d_dob,@d_age,@d_address,@d_contact,@d_bloodgroup,@d_desease_history
            cm.Parameters.AddWithValue("@s_Date", DateTime.Parse(txtSDate.Text));
            cm.Parameters.AddWithValue("@s_Id", txtsID.Text);
            cm.Parameters.AddWithValue("@s_BNo", txtbillno.Text);
            cm.Parameters.AddWithValue("@s_Cname", ddlCname.Text);
            cm.Parameters.AddWithValue("@s_TAmount", txtAmm.Text);
            cm.Parameters.AddWithValue("@s_GST", txtGST.Text);
            cm.Parameters.AddWithValue("@s_ATAmount", txtActAmm.Text);


            sda.InsertCommand = cm;
            DataRow drw = ds.Tables[0].NewRow();
            drw[0] = DateTime.Parse(txtSDate.Text);
            drw[1] = int.Parse(txtsID.Text);
            drw[2] = int.Parse(txtbillno.Text);
            drw[3] = ddlCname.Text;
            drw[4] = float.Parse(txtAmm.Text);
            drw[5] = float.Parse(txtGST.Text);
            drw[6] = float.Parse(txtActAmm.Text);
            ds.Tables[0].Rows.Add(drw);


            sda.Update(ds.Tables[0]);
            ds.AcceptChanges();
            showData();
            clear();
        }
        else
        {
            Response.Write("<script>alert('Please fill your information ');</script>");
        }
    }

    protected void btnedit0_Click(object sender, EventArgs e)
    {
        cm = new SqlCommand("update SALES set s_Date=@s_Date,s_BNo=@s_BNo,s_Cname=@s_Cname,s_TAmount=@s_TAmount,s_GST=@s_GST,s_ATAmount=@s_ATAmount where s_Id=@s_Id", cn);

        //@d_id,@d_name,@d_dob,@d_age,@d_address,@d_contact,@d_bloodgroup,@d_desease_history
        cm.Parameters.AddWithValue("@s_Date", DateTime.Parse(txtSDate.Text));
        cm.Parameters.AddWithValue("@s_Id", txtsID.Text);
        cm.Parameters.AddWithValue("@s_BNo", txtbillno.Text);
        cm.Parameters.AddWithValue("@s_Cname", ddlCname.Text);
        cm.Parameters.AddWithValue("@s_TAmount", txtAmm.Text);
        cm.Parameters.AddWithValue("@s_GST", txtGST.Text);
        cm.Parameters.AddWithValue("@s_ATAmount", txtActAmm.Text);


        sda.UpdateCommand = cm;
        DataRow[] drw = ds.Tables[0].Select(String.Format("s_Id=" + int.Parse(txtsID.Text)));
        drw[0][0] = DateTime.Parse(txtSDate.Text);
        drw[0][1] = int.Parse(txtsID.Text);
        drw[0][2] = int.Parse(txtbillno.Text);
        drw[0][3] = ddlCname.Text;
        drw[0][4] = float.Parse(txtAmm.Text);
        drw[0][5] = float.Parse(txtGST.Text);
        drw[0][6] = float.Parse(txtActAmm.Text);



        sda.Update(ds.Tables[0]);
        ds.AcceptChanges();
        showData();
        clear();
    }
    protected void btndelete0_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from SALES where s_Id=@s_Id", cn);

            //@d_id,@d_name,@d_dob,@d_age,@d_address,@d_contact,@d_bloodgroup,@d_desease_history
            cm.Parameters.AddWithValue("@s_Id", txtsID.Text);

            sda.DeleteCommand = cm;
            DataRow[] drw = ds.Tables[0].Select(String.Format("s_Id=" + int.Parse(txtsID.Text)));
            drw[0][0] = int.Parse(txtsID.Text);

            ds.Tables[0].Rows[0].Delete();
            sda.Update(ds.Tables[0]);
            ds.AcceptChanges();
            showData();
            clear();
        }
        catch (Exception e1) { }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        clear();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
    }
    protected void btnCompany_Click(object sender, EventArgs e)
    {
        
        showData2();
    }
}
