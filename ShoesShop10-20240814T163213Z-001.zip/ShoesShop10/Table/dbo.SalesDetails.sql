﻿CREATE TABLE [dbo].[SALESDETAILS] (
    [s_Date]     INT          NOT NULL,
    [s_Id]       INT          NULL,
    [s_No]       INT          NULL,
    [s_CName]    VARCHAR (50) NULL,
    [s_SRNO]     INT          NULL,
    [s_Item]     VARCHAR (50) NULL,
    [s_Size]     INT          NULL,
    [s_Quantity] INT          NULL,
    [s_Amount]   FLOAT (53)   NULL,
    [s_Total]    FLOAT (53)   NULL,
    [s_BAmmount] FLOAT (53)   NULL,
    PRIMARY KEY CLUSTERED ([s_Date] ASC)
);

