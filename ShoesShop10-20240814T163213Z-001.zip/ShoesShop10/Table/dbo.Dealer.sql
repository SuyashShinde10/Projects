﻿CREATE TABLE [dbo].[DEALER]
(
	[d_Id] INT NOT NULL PRIMARY KEY, 
    [d_Name] VARCHAR(50) NULL, 
    [d_Adress] VARCHAR(50) NULL, 
    [d_No] INT NULL, 
    [d_EId] VARCHAR(50) NULL, 
    [d_UPIId] NCHAR(10) NULL, 
    [d_GST] FLOAT NULL
)
