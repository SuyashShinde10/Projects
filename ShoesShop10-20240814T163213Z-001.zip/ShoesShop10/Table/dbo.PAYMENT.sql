﻿CREATE TABLE [dbo].[PAYMENT]
(
	[p_Id] INT NOT NULL PRIMARY KEY, 
    [p_Name] VARCHAR(50) NULL, 
    [p_Payment] NCHAR(10) NULL, 
    [p_POption] VARCHAR(50) NULL
)
