﻿CREATE TABLE [dbo].[CUSTOMER]
(
	[cus_ID] INT NOT NULL PRIMARY KEY, 
    [cus_Name] VARCHAR(50) NULL, 
    [cus_No] INT NULL, 
    [cus_EId] NCHAR(10) NULL
)
