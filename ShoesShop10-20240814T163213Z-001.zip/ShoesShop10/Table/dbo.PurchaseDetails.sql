﻿CREATE TABLE [dbo].[PURCHSEDETAILS] (
    [p_Date]       INT          NOT NULL,
    [p_Id]         INT          NULL,
    [p_No]         INT          NULL,
    [p_CName]      VARCHAR (50) NULL,
    [p_SRNO]       INT          NULL,
    [p_Item]       VARCHAR (50) NULL,
    [p_size]       INT          NULL,
    [p_Quantity]   INT          NULL,
    [p_Amount]     FLOAT (53)   NULL,
    [p_Total]      FLOAT (53)   NULL,
    [p_BillAmount] FLOAT (53)   NULL,
    PRIMARY KEY CLUSTERED ([p_Date] ASC)
);

