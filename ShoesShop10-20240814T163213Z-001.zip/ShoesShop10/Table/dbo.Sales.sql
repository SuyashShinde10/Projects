﻿CREATE TABLE [dbo].[SALES] (
    [s_Date]     INT           NOT NULL,
    [s_Id]       INT           NOT NULL,
    [s_BNo]      INT           NULL,
    [s_Cname]    NVARCHAR (50) NULL,
    [s_TAmount]  INT           NULL,
    [s_GST]      INT           NULL,
    [s_ATAmount] INT           NULL,
    PRIMARY KEY CLUSTERED ([s_Id] ASC)
);

