﻿CREATE TABLE [dbo].[STOCK] (
    [s_Date]     INT          NULL,
    [s_Item]     VARCHAR (50) NULL,
    [s_Size]     INT          NULL,
    [s_Quantity] INT          NULL,
    [s_ID]       VARCHAR(50)   NOT NULL, 
    CONSTRAINT [PK_STOCK] PRIMARY KEY ([s_ID])
);

