﻿CREATE TABLE [dbo].[PURCHASE] (
    [P_Date]         INT           NOT NULL,
    [P_Id]           INT           NOT NULL,
    [P_Cname]        NVARCHAR (50) NULL,
    [P_BNo]          INT           NULL,
    [P_Amount]       INT           NULL,
    [P_GST]          INT           NULL,
    [P_ActualAmount] NVARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([P_Id] ASC)
);

