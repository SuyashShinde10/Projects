﻿CREATE TABLE [dbo].[ITEM] (
    [I_id]     INT          NOT NULL,
    [I_Name]    VARCHAR (50) NULL,
    [I_Company] VARCHAR (50) NULL,
    [I_Code]    INT          NULL,
    [I_Gender]  VARCHAR (50) NULL,
    [I_Design]  VARCHAR (50) NULL,
    [I_No]      FLOAT (53)   NULL,
    [I_DPrice]  NCHAR (10)   NULL,
    [I_SPrice]  NCHAR (10)   NULL,
    [I_Date]    NCHAR (10)   NULL,
    PRIMARY KEY CLUSTERED ([I_id] ASC)
);

