﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class frmItemMaster : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    DataSet ds;
    SqlDataAdapter sda;
    int i, c, n;

    protected void Page_Load(object sender, EventArgs e)
    {
        Class1 x = new Class1();

        cn = new SqlConnection(x.s);
        
        cn.Open();
        ds = new DataSet();
        sda = new SqlDataAdapter();
        showData();
    }
    private void showData()
    {
        ds.Clear();
        cm = new SqlCommand("select * from ITEM", cn);
        sda.SelectCommand = cm;
        sda.Fill(ds, "ITEM");
        ds.AcceptChanges();
        sda.Update(ds.Tables[0]);

        n = ds.Tables[0].Rows.Count;

        GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();

    }
    public void clear()
    {
        txtIID.Text = "";
        txtIname.Text = "";
        ddlCompany.Text = "";
        ddlIcode.Text = "";
        ddlGender.Text = "";
        txtDesign.Text = "";
        ddlNO.Text = "";
        txtDPrice.Text = "";
        txtSPrice.Text = "";
         
    }
    private void eachRecord()
    {
        // showData();
        try
        {
            txtIID.Text = ds.Tables[0].Rows[c].ItemArray[0].ToString();
            //DateTime d1 = DateTime.Parse(ds.Tables[0].Rows[c].ItemArray[2].ToString());
            txtIname.Text = ds.Tables[0].Rows[c].ItemArray[1].ToString();
            ddlCompany.Text = ds.Tables[0].Rows[c].ItemArray[2].ToString();
            //ddlCompany.Text = d1.ToShortDateString();
            ddlIcode.Text = ds.Tables[0].Rows[c].ItemArray[3].ToString();
            ddlGender.Text = ds.Tables[0].Rows[c].ItemArray[4].ToString();
            txtDesign.Text = ds.Tables[0].Rows[c].ItemArray[5].ToString();

            ddlNO.Text = ds.Tables[0].Rows[c].ItemArray[6].ToString();
            txtDPrice.Text = ds.Tables[0].Rows[c].ItemArray[7].ToString();
            txtSPrice.Text = ds.Tables[0].Rows[c].ItemArray[8].ToString();
            //ddlDateModi.Text = ds.Tables[0].Rows[c].ItemArray[9].ToString();
        }
        catch (Exception e1) { }
    }




    //protected void btnShowDate0_Click(object sender, EventArgs e)
    //{
    //    ds.Clear();
    //    GridView1.DataSource = null;
    //    GridView1.DataBind();
    //}
    
    protected void btnprev_Click(object sender, EventArgs e)
    {
        // previous
        if (c > 0)
        {
            c--;

            eachRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script> alert('First Record');</script>");
        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {

        try
        {
            //showData();
            cm = new SqlCommand("Select * from ITEM where I_id=" + int.Parse(txtIID.Text), cn);
            SqlDataReader dr = cm.ExecuteReader();
            if (dr.Read())
            {
                //txtIID.Text = dr[1].ToString();
                //DateTime d1 = DateTime.Parse(dr[2].ToString());
                txtIname.Text = dr[1].ToString();
                ddlCompany.Text = dr[2].ToString();
                ddlIcode.Text = dr[3].ToString();
                ddlGender.Text = dr[4].ToString();
                txtDesign.Text = dr[5].ToString();
                ddlNO.Text = dr[6].ToString();
                txtDPrice.Text = dr[7].ToString();
                txtSPrice.Text = dr[8].ToString();
                //ddlDateModi.Text = dr[9].ToString();
            }
            else
            {

            }
            dr.Close();
        }
        catch (Exception e11)
        {
            Response.Write(e11.ToString());
        }
    }
    protected void btnfirst_Click(object sender, EventArgs e)
    {
        //first record
        c = 0;

        eachRecord();
        ViewState["c"] = c.ToString();
    }


    protected void btnnxt_Click(object sender, EventArgs e)
    {
        //last record
        if (c < n - 1)
        {
            c++;

            eachRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script> alert('Last Record');</script>");

        }
    }

    protected void btnist_Click(object sender, EventArgs e)
    {
        //Last record
        try
        {
            c = n - 1;


            eachRecord();
            ViewState["c"] = c.ToString();
        }
        catch
        {
            c = n;
        }
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        showData();
        if (txtIname.Text != "" && ddlCompany.Text != "" && ddlIcode.Text != "" && ddlGender.Text != "" && txtDesign.Text != "" && ddlNO.Text != "" && txtDPrice.Text != "" && txtSPrice.Text != "")
        {
            cm = new SqlCommand("insert into  ITEM (I_Name,I_Company,I_Code,I_Gender,I_Design,I_No,I_DPrice,I_SPrice) values(@I_Name,@I_Company,@I_Code,@I_Gender,@I_Design,@I_No,@I_DPrice,@I_SPrice)", cn);

            //@d_id,@d_name,@d_dob,@d_age,@d_address,@d_contact,@d_bloodgroup,@d_desease_history
            //  cm.Parameters.AddWithValue("@I_id", txtIID.Text);
            cm.Parameters.AddWithValue("@I_Name", txtIname.Text);
            cm.Parameters.AddWithValue("@I_Company", ddlCompany.Text);
            cm.Parameters.AddWithValue("@I_Code", ddlIcode.Text);
            cm.Parameters.AddWithValue("@I_Gender", ddlGender.Text);
            cm.Parameters.AddWithValue("@I_Design", txtDesign.Text);
            cm.Parameters.AddWithValue("@I_No", ddlNO.Text);
            cm.Parameters.AddWithValue("@I_DPrice", txtDPrice.Text);
            cm.Parameters.AddWithValue("@I_SPrice", txtSPrice.Text);
            //cm.Parameters.AddWithValue("@I_Date", ddlDateModi.Text);

            sda.InsertCommand = cm;
            DataRow drw = ds.Tables[0].NewRow();
            //  drw[0] = int.Parse(txtIID.Text);
            drw[1] = txtIname.Text;
            drw[2] = ddlCompany.Text;
            drw[3] = int.Parse(ddlIcode.Text);
            drw[4] = ddlGender.Text;
            drw[5] = txtDesign.Text;
            drw[6] = int.Parse(ddlNO.Text);
            drw[7] = float.Parse(txtDPrice.Text);
            drw[8] = float.Parse(txtSPrice.Text);
            ds.Tables[0].Rows.Add(drw);

            sda.Update(ds.Tables[0]);
            ds.AcceptChanges();
            showData();
            clear();
        }
        else
        {
            Response.Write("<script>alert('Please fill your information ');</script>");
        }
    }


    protected void btnedit_Click(object sender, EventArgs e)
    {

        cm = new SqlCommand("update  ITEM set I_Name=@I_Name,I_Company=@I_Company,I_Code=@I_Code,I_Gender=@I_Gender,I_Design=@I_Design,I_No=@I_No,I_DPrice=@I_DPrice,I_SPrice=@I_SPrice  where I_id=@I_id", cn);

        //@d_id,@d_name,@d_dob,@d_age,@d_address,@d_contact,@d_bloodgroup,@d_desease_history
        cm.Parameters.AddWithValue("@I_id", txtIID.Text);
        cm.Parameters.AddWithValue("@I_Name", txtIname.Text);
        cm.Parameters.AddWithValue("@I_Company", ddlCompany.Text);
        cm.Parameters.AddWithValue("@I_Code", ddlIcode.Text);
        cm.Parameters.AddWithValue("@I_Gender", ddlGender.Text);
        cm.Parameters.AddWithValue("@I_Design", txtDesign.Text);
        cm.Parameters.AddWithValue("@I_No", ddlNO.Text);
        cm.Parameters.AddWithValue("@I_DPrice", txtDPrice.Text);
        cm.Parameters.AddWithValue("@I_SPrice", txtSPrice.Text);
        //cm.Parameters.AddWithValue("@I_Date", ddlDateModi.Text);
         

        sda.UpdateCommand = cm;
        DataRow[] drw = ds.Tables[0].Select(String.Format("I_id=" + int.Parse(txtIID.Text)));
        drw[0][0] = int.Parse(txtIID.Text);
        drw[0][1] = txtIname.Text;
        drw[0][2] = ddlCompany.Text;
        drw[0][3] = int.Parse(ddlIcode.Text);
        //drw[0][4] = ddlIcode.Text;
        drw[0][4] = ddlGender.Text;
        drw[0][5] = txtDesign.Text;
        drw[0][6] = int.Parse(ddlNO.Text);
        drw[0][7] = float.Parse(txtDPrice.Text);
        drw[0][8] = float.Parse(txtSPrice.Text);
        //drw[0][7] = ddlDateModi.Text;


        sda.Update(ds.Tables[0]);
        ds.AcceptChanges();
        showData();
        clear();
    }

    protected void btndelete_Click(object sender, EventArgs e)
    {
        //   cm = new SqlCommand("delete from ITEM ", cn);
        //cm.ExecuteNonQuery ();

        try
        {
            cm = new SqlCommand("delete from ITEM where I_id=@I_id", cn);

            //@d_id,@d_name,@d_dob,@d_age,@d_address,@d_contact,@d_bloodgroup,@d_desease_history
            cm.Parameters.AddWithValue("@I_id", txtIID.Text);

            sda.DeleteCommand = cm;
            DataRow[] drw = ds.Tables[0].Select(String.Format("I_id=" + int.Parse(txtIID.Text)));
            drw[0][0] = int.Parse(txtIID.Text);

            ds.Tables[0].Rows[0].Delete();
            sda.Update(ds.Tables[0]);
            ds.AcceptChanges();
            showData();
            clear();
        }
        catch (Exception e1) { }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        clear();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
    }
}
